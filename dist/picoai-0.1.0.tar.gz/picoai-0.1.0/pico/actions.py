def addition(a: int, b: int) -> int:
    return a + b

def subtraction(a: int, b: int) -> int:
    return a - b

def pico(name: str) -> str:
    return name + " is my chico"